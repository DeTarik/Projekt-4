import org.junit.Before;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

public class AListStub extends AList {



        private AList aList;
        private Biblotek biblotek;

        @Before
        public void setUp() throws Exception {
            biblotek = mock(Biblotek.class);
            aList = new AList();
        }

        @Test
        public void taBortBok() {



        }





    }





